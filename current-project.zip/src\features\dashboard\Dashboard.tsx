import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { dbService } from '@/services/db';
import { StatCard } from '@/components/common/StatCard';
import { formatCurrency } from '@/utils';
import { 
  Plus, 
  Calendar,
  IndianRupee,
  Users,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card';

export function Dashboard() {
  const navigate = useNavigate();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: dbService.getDashboardStats,
  });

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      
      {/* Welcome Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
            Good morning, Sharma Ji! <span className="text-2xl">🙏</span>
          </h2>
          <p className="text-[15px] font-medium text-muted-foreground mt-1">
            Here's your business at a glance — March 2025
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <Button variant="outline" className="gap-2 bg-white rounded-full shadow-sm border-border/60 font-medium">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            Mar 2025
          </Button>
          <Button 
            className="gap-2 rounded-full bg-primary hover:bg-primary/90 text-white shadow-sm font-semibold px-6"
            onClick={() => navigate('/invoices?create=true')}
          >
            <Plus className="h-4 w-4" /> New Invoice
          </Button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Revenue"
          value="₹48.2L" // Mocking exact data from screenshot, or could use formatCurrency(stats?.totalRevenue ?? 0)
          change={12.4}
          description="vs last month"
          icon={IndianRupee}
          iconColor="green"
          trend="up"
          loading={statsLoading}
        />
        <StatCard
          title="Active Customers"
          value="1,247"
          change={23}
          description="this month"
          icon={Users}
          iconColor="blue"
          trend="up"
          loading={statsLoading}
        />
        <StatCard
          title="Outstanding"
          value="₹8.74L"
          description="12 invoices pending"
          icon={AlertCircle}
          iconColor="red"
          trend="high"
          loading={statsLoading}
        />
        <StatCard
          title="Net Profit"
          value="₹22.4L"
          change={8.1}
          description="vs last month"
          icon={TrendingUp}
          iconColor="yellow"
          trend="up"
          loading={statsLoading}
        />
      </div>

      {/* Charts Section */}
      <div className="grid gap-6 md:grid-cols-3">
        {/* Revenue Overview Chart Placeholder */}
        <Card className="md:col-span-2 rounded-2xl border-border/40 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <div>
              <CardTitle className="text-lg">Revenue Overview</CardTitle>
              <div className="text-sm font-medium text-muted-foreground mt-0.5">FY 2024-25 · Monthly breakdown</div>
            </div>
            <div className="flex items-center gap-4 text-sm font-medium">
              <div className="flex items-center gap-1.5"><div className="w-3 h-0.5 bg-green-600 rounded-full" /> Revenue</div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-0.5 bg-terracotta rounded-full bg-[#C96B3C]" /> Expenses</div>
              <div className="flex items-center gap-1.5"><div className="w-3 h-0.5 bg-yellow-500 rounded-full" /> Profit</div>
            </div>
          </CardHeader>
          <CardContent>
            {/* SVG placeholder mimicking the spline chart */}
            <div className="w-full h-[280px] mt-4 relative">
              <svg viewBox="0 0 800 250" className="w-full h-full preserve-3d" preserveAspectRatio="none">
                {/* Grid lines */}
                <path d="M 0 50 L 800 50" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="4 4" />
                <path d="M 0 100 L 800 100" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="4 4" />
                <path d="M 0 150 L 800 150" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="4 4" />
                <path d="M 0 200 L 800 200" stroke="#e5e7eb" strokeWidth="1" strokeDasharray="4 4" />
                
                {/* Profit Line (Yellow) */}
                <path d="M 0 180 Q 100 160 200 190 T 400 170 T 600 180 T 800 160" fill="none" stroke="#eab308" strokeWidth="2.5" />
                
                {/* Expense Line (Terracotta) */}
                <path d="M 0 170 Q 100 150 200 170 T 400 140 T 600 160 T 800 150" fill="none" stroke="#C96B3C" strokeWidth="2.5" />
                
                {/* Revenue Line (Green) */}
                <path d="M 0 120 Q 100 80 200 110 T 400 60 T 600 90 T 800 70" fill="none" stroke="#16a34a" strokeWidth="3" />
                {/* Revenue Fill Area */}
                <path d="M 0 120 Q 100 80 200 110 T 400 60 T 600 90 T 800 70 L 800 250 L 0 250 Z" fill="url(#greenGradient)" opacity="0.1" />
                
                <defs>
                  <linearGradient id="greenGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#16a34a" />
                    <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
              {/* X-axis labels */}
              <div className="absolute bottom-0 w-full flex justify-between text-[11px] font-medium text-muted-foreground px-4">
                <span>Apr</span><span>May</span><span>Jun</span><span>Jul</span><span>Aug</span><span>Sep</span><span>Oct</span><span>Nov</span><span>Dec</span><span>Jan</span><span>Feb</span><span>Mar</span>
              </div>
              {/* Y-axis labels */}
              <div className="absolute left-0 top-0 h-full flex flex-col justify-between text-[11px] font-medium text-muted-foreground pb-6">
                <span>₹600K</span><span>₹450K</span><span>₹300K</span><span>₹150K</span><span>₹0K</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Sales by Category Chart Placeholder */}
        <Card className="rounded-2xl border-border/40 shadow-sm flex flex-col">
          <CardHeader>
            <CardTitle className="text-lg">Sales by Category</CardTitle>
            <div className="text-sm font-medium text-muted-foreground mt-0.5">This month</div>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col items-center justify-center pt-2 pb-6">
            <div className="relative w-48 h-48 mb-8">
              {/* Fake Donut Chart via SVG */}
              <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                <circle cx="50" cy="50" r="40" fill="transparent" stroke="#2E4A9E" strokeWidth="16" strokeDasharray="251.2" strokeDashoffset="0" />
                <circle cx="50" cy="50" r="40" fill="transparent" stroke="#1F5C3A" strokeWidth="16" strokeDasharray="251.2" strokeDashoffset="75" />
                <circle cx="50" cy="50" r="40" fill="transparent" stroke="#C96B3C" strokeWidth="16" strokeDasharray="251.2" strokeDashoffset="160" />
                <circle cx="50" cy="50" r="40" fill="transparent" stroke="#eab308" strokeWidth="16" strokeDasharray="251.2" strokeDashoffset="210" />
                <circle cx="50" cy="50" r="40" fill="transparent" stroke="#9ca3af" strokeWidth="16" strokeDasharray="251.2" strokeDashoffset="240" />
              </svg>
            </div>
            
            <div className="w-full space-y-2.5 px-2">
              <div className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-[#1F5C3A]" /> <span className="font-medium">Grains</span></div>
                <span className="font-semibold text-foreground">₹145K</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-[#2E4A9E]" /> <span className="font-medium">Pulses</span></div>
                <span className="font-semibold text-foreground">₹89K</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-[#C96B3C]" /> <span className="font-medium">Oils</span></div>
                <span className="font-semibold text-foreground">₹67K</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-yellow-500" /> <span className="font-medium">Groceries</span></div>
                <span className="font-semibold text-foreground">₹52K</span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-gray-400" /> <span className="font-medium">Others</span></div>
                <span className="font-semibold text-foreground">₹31K</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

    </div>
  );
}
